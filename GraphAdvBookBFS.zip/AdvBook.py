'''
Tyler Watson
Friday, April 6
R. Vincent, instructor
Assignment 2
'''

'''
Program to go through a "Choose your own adventure" book implemented as a
directed graph using breadth first search.

'''
from graph import *
from bfs import *

file = input("Type in the name of the file you would like to examine: ") 
file = open(file)
a = file.readline()
G = digraph(int(a))
count = 0
end_pages = []
for line in file.readlines():
    pages = line.split() #Split up numbers
    if len(pages) > 1:
        for page in pages[1:]: #Don't count the first element
            G.addEdge(count, int(page)-1) #Add an edge from page to the attainable pages from  that page
    else:
        end_pages.append(count) #If the page has no attainable pages, its an end page
    count += 1
    

A = BFS(G, 0)
end_path = [] #List for path until end page
no_path = [] #List of end pages that are not attainable
for page in end_pages:
    if A.hasPathTo(page): 
        end_path.append(A.pathTo(page))
    else:
        no_path.append(page+1)
shortest = min(end_path) 
path_page_num = [] #Real page number
for element in shortest:
    path_page_num.append(element+1) #Convert back to actual page numbers
print("The shortest path from the first page to", shortest[-1]+1, "is", len(path_page_num), "steps and the order is", path_page_num)
if no_path:
    print("Not all pages are reachable from the first page")

from BST import *

Empty_BST = BST()
assert len(Empty_BST) == 0
assert bool(Empty_BST) == False
assert Empty_BST.depth() == 0
assert str(Empty_BST) == ''

NonEmpty_BST = BST()
NonEmpty_BST.put(5,5)
NonEmpty_BST.put(8,8)
NonEmpty_BST.put(9,9)
NonEmpty_BST.put(10,10)
assert len(NonEmpty_BST) == 4
assert bool(NonEmpty_BST) == True
assert NonEmpty_BST.depth() == 4
assert str(NonEmpty_BST) == '5:5,8:8,9:9,10:10,'
assert NonEmpty_BST.get(5) == 5
assert NonEmpty_BST.minKey() == 5
assert NonEmpty_BST.maxKey() == 10


from random import shuffle
def tester(N):
    ls = list(range(0,N-1)) #Create a list of N items
    shuffle(ls)
    A = BST()
    for item in ls:
        A.put(item)
    return A.depth()

depth32 = []
for i in range(0,100):
    depth32.append(tester(32))

depth64 = []
for i in range(0,100):
    depth64.append(tester(64))

depth128 = []
for i in range(0,100):
    depth128.append(tester(128))

depth256 = []
for i in range(0,100):
    depth256.append(tester(256))


print(' {}   {}   {}   {}'.format('N','MIN','MAX','MEAN'))
print(' {}   {}    {}    {}'.format('32',min(depth32),max(depth32),sum(depth32)/len(depth32)))   
print(' {}   {}    {}    {}'.format('64',min(depth64),max(depth64),sum(depth64)/len(depth64)))
print('{}  {}    {}    {}'.format('128',min(depth128),max(depth128),sum(depth128)/len(depth128)))
print('{}  {}    {}    {}'.format('256',min(depth256),max(depth256),sum(depth256)/len(depth256)))

''' As the size increases by a factor of 2, the mean depth increase by about 2. Thus, the size of the tree directly affects its depth'''

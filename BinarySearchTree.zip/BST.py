# Template file for Assignment 3.
#
class BST(object):
    '''Class that represents a Binary Search Tree.'''
    class Node(object):
        '''A single node within a BST.'''
        def __init__(self, key, val = None):
            self.key = key
            self.val = val
            self.left = None
            self.right = None

        def __repr__(self):
            if self.val == None:
                return repr(self.key)
            else:
                return repr(self.key) + ':' + repr(self.val)

    def __init__(self):
        self.root = None

    def __len__(self):
        '''Compute the size (number of key/value pairs) of the BST.'''
        def size(node):
            '''Compute the size of the tree below this node.'''
            if node == None:
                return 0
            else:
                return 1 + size(node.left) + size(node.right)
        return size(self.root)

    def __bool__(self):
        '''Convert a BST into a Boolean value. Like most Python collections,
        the logic here is that any non-empty BST evaluates as True.'''
        return self.root != None
    
    def put(self, key, val = None):
        '''Insert the key-value pair into
        the BST.'''
        def _put(node, key, val):
            if node == None:
                return BST.Node(key, val)
            elif key < node.key:
                node.left = _put(node.left, key, val)
            elif key > node.key:
                node.right = _put(node.right, key, val)
            else:
                node.val = val
            return node
        self.root = _put(self.root, key, val)

    @staticmethod
    def _get(node, key):
        '''Helper function for get() and contains()'''
        while node.key != key: #So long as we have not found the right node
            if node == None: #If the node is none, return none
                return None
            elif key < node.key: #If the key we are looking for is smaller then the node, run through the loop again with node as the node to the left
                node = node.left
            else:
                node = node.right #Same concept as elif key < node.key
        return node #once the node is found the loop is done return the node


    def get(self, key):
        '''Get the value associated with
        the given 'key'.'''
        x = BST._get(self.root, key)
        if x == None:
            return None
        else:
            return x.val

    def contains(self, key):
        return BST._get(self.root, key) != None

    def depth(self):
        '''Return the maximum depth of the tree.'''
        def depth(node):
            '''Compute the depth of the tree below this node.'''
            if node == None:
                return 0
            else:
                return 1 + max(depth(node.left), depth(node.right))
        return depth(self.root)

    def minKey(self):
        node = self.root #Set initial node to check
        while node.left: #So long as there is still a value to the left
            node = node.left #If there is a node to teh left, change the node to this node
        return node.key #Return the key of the leftmost node

    def maxKey(self): #Same concept as minKey but for the right most key
        node = self.root
        while node.right:
            node = node.right
        return node.key

    @staticmethod
    def traverse(root, func):
        if root == None:
            return
        BST.traverse(root.left, func) #Traverse left
        func(root) #Visit node
        BST.traverse(root.right, func) #Traverse right

    def __repr__(self):
        string = ''
        def _string(x): #Helper function to call for tree traversal
            nonlocal string 
            string += str(x.key) + ':' + str(x.val) + ','
        self.traverse(self.root, _string)
        return string
    
        
        
